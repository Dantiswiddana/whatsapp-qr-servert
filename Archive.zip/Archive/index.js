import express from 'express';
import qrcode from 'qrcode';
import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.static(path.join(__dirname, 'public')));

let currentQR = '';
let socketInitialized = false;

app.get('/get-qr', async (req, res) => {
  if (currentQR) {
    return res.send(currentQR);
  }

  if (!socketInitialized) {
    socketInitialized = true;

    const { state, saveCreds } = await useMultiFileAuthState('auth_info_baileys');
    const sock = makeWASocket({ auth: state, printQRInTerminal: false });

    sock.ev.on('connection.update', async (update) => {
      const { connection, qr } = update;

      if (qr) {
        currentQR = await qrcode.toDataURL(qr);
        console.log('✅ QR Code généré');
      }

      if (connection === 'open') {
        console.log('✅ WhatsApp connecté');
      }

      if (connection === 'close') {
        socketInitialized = false;
        currentQR = '';
        console.log('🔌 Déconnecté. Socket réinitialisé.');
      }
    });

    sock.ev.on('creds.update', saveCreds);
  }

  // Attente du QR
  let attempts = 0;
  const maxAttempts = 10;

  const interval = setInterval(() => {
    if (currentQR) {
      clearInterval(interval);
      return res.send(currentQR);
    }

    if (++attempts >= maxAttempts) {
      clearInterval(interval);
      return res.status(500).send('Erreur : QR code non généré');
    }
  }, 500);
});

app.listen(port, () => {
  console.log(`🚀 Serveur en ligne sur http://localhost:${port}`);
});
